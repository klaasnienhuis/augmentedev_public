Welcome to the readme of the AugmentPublisher script. The readme contains a list of the contents of the installer and some instructions on how to install the script.
You can install the mzp-file by dropping it onto any viewport, or by running it from the menu: MAXScript>>Run file...
If you want to check out the contents of the mzp-file yourself, you can unzip it just like a zip-file.

A message from the developer
	This script enables you to publish models directly to your augment account on www.augment.com.
	License: This script can be used freely. It can't be edited or redistributed by other people than augment
	Support: contact@augmentedev.com
	Contact: twitter: https://twitter.com/#!/AugmenteDev, http://augmentedev.com/home.php#home, developer www.klaasnienhuis.nl, twitter: klaasnienhuis augment@klaasnienhuis.nl

name "Augment"
description "Klaas Nienhuis Scripts"
version 1.05

The following files are copied to your system
	scriptfiles\augmentedev.mse >> $userScripts\KlaasTools\Augment\scriptfiles\
	scriptfiles\augmentedev_bake.mse >> $userScripts\KlaasTools\Augment\scriptfiles\
	scriptfiles\augmentedev_file.mse >> $userScripts\KlaasTools\Augment\scriptfiles\
	scriptfiles\augmentedev_gui.mse >> $userScripts\KlaasTools\Augment\scriptfiles\
	scriptfiles\augmentedev_htmlPost.mse >> $userScripts\KlaasTools\Augment\scriptfiles\
	scriptfiles\augmentedev_map.mse >> $userScripts\KlaasTools\Augment\scriptfiles\
	scriptfiles\augmentedev_multithread.mse >> $userScripts\KlaasTools\Augment\scriptfiles\
	scriptfiles\augmentedev_obj.mse >> $userScripts\KlaasTools\Augment\scriptfiles\
	scriptfiles\augmentedev_rolloutFunctions.mse >> $userScripts\KlaasTools\Augment\scriptfiles\
	scriptfiles\augmentedev_scene.mse >> $userScripts\KlaasTools\Augment\scriptfiles\
	scriptfiles\augmentedev_screengrab.mse >> $userScripts\KlaasTools\Augment\scriptfiles\
	scriptfiles\augmentedev_studio.mse >> $userScripts\KlaasTools\Augment\scriptfiles\
	scriptfiles\augmentedev_zip.mse >> $userScripts\KlaasTools\Augment\scriptfiles\
	art\augmentedevBanner_002.jpg >> $userScripts\KlaasTools\Augment\art\
	art\augment_16i.bmp >> $userIcons\
	art\augment_24i.bmp >> $userIcons\
	art\augment_24i.ico >> $userIcons\
	installfiles\KlaasNienhuis_Augment_Install.ms >> $userScripts\KlaasTools\Augment\
	presets\obj_preset_augmentedev.ini >> $userScripts\KlaasTools\Augment\presets\
	scriptfiles\augmentedev_errorhandling.mse >> $userScripts\KlaasTools\Augment\scriptfiles\

If dropped on the viewport, the following scripts are executed
	KlaasNienhuis_Augment_Install.ms

If executed by the menu: MAXScript>>Run file... the following scripts are executed 
	KlaasNienhuis_Augment_Install.ms

